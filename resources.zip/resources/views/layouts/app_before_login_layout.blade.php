<!-- include Header -->
    @include('frontend.includes.header_after_login')
<!-- End include Header -->
    @yield('content')
   <!-- main End -->
<!-- include footer -->
    @include('frontend.includes.footer_after_login')
<!-- include footer -->
