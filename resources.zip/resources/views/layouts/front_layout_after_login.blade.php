 @include('frontend.includes.header_after_login')


        @yield('content')


 @include('frontend.includes.footer_before_login')
