 @include('includes.header_before_login')


        @yield('content')


 @include('includes.footer_before_login')
