<html>
<body>
  <div id="spam">
    <h1>The site is only available in Austria</h1>
</body>
</html>